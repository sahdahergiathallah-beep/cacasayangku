# Galaksi Caca 💗🌌

Website romantis interaktif untuk Caca, dengan galaksi 3D, foto, surat, dan melodi sederhana.

## Cara mengunggah ke GitHub Pages

1. Masuk ke https://github.com dan buat repository baru.
2. Beri nama repository, misalnya `galaksi-caca`.
3. Pilih **Public**, lalu buat repository.
4. Ekstrak ZIP ini di perangkatmu.
5. Unggah file `index.html` ke halaman utama repository:
   - pilih **Add file** → **Upload files**
   - unggah `index.html`
   - klik **Commit changes**
6. Buka **Settings** → **Pages**.
7. Pada bagian **Build and deployment**, pilih **Deploy from a branch**.
8. Pilih branch `main` dan folder `/(root)`, lalu klik **Save**.
9. Tunggu beberapa menit. GitHub akan menampilkan alamat publik seperti:
   `https://USERNAME.github.io/galaksi-caca/`

## Catatan

- Foto sudah tertanam di dalam `index.html`, jadi tidak perlu mengunggah foto satu per satu.
- Efek 3D memakai Three.js dari CDN, sehingga pengunjung perlu koneksi internet.
- Jika repository bernama selain `galaksi-caca`, URL publik akan mengikuti nama repository tersebut.
